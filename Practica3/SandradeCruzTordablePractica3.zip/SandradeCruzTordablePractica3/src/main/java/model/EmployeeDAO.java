/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package model;

import java.io.*;
import java.util.*;
import java.util.stream.Collectors;

/**
 *
 * @author sancru
 */
public class EmployeeDAO {
    private List<Employee> empleados = new ArrayList<>();
    private String csvOriginal;
    
    public boolean cargarCSV(String ruta) {
        empleados.clear();
         this.csvOriginal = ruta;
        try (BufferedReader br = new BufferedReader(new FileReader(ruta))) {
            String linea;
            while ((linea = br.readLine()) != null) {
                String[] partes = linea.split(",");
                if (partes.length == 4) {
                    int id = Integer.parseInt(partes[0].trim());
                    String nombre = partes[1].trim();
                    String apellido = partes[2].trim();
                    String depStr = partes[3].trim();
                    int departamento;

                    if (depStr.isEmpty() || depStr.equals("-")) {
                        departamento = -1; //No tiene departamento
                    } else {
                        departamento = Integer.parseInt(depStr);
                    }

                    empleados.add(new Employee(id, nombre, apellido, departamento));
                }
            }
            return true;
        } catch (Exception e) {
            return false; 
        }
    }

    public boolean fusionarCSV(String ruta) {
        try (BufferedReader br = new BufferedReader(new FileReader(ruta))) {
            String linea;
            while ((linea = br.readLine()) != null) {
                String[] partes = linea.split(",");
                if (partes.length >= 4) {
                    int id = Integer.parseInt(partes[0].trim());
                    String nombre = partes[1].trim();
                    String apellidos = partes[2].trim();
                    String depStr = partes[3].trim();
                    int departamento = (depStr.isEmpty() || depStr.equals("-")) ? -1 : Integer.parseInt(depStr);
                    //Actualizamos el array list con el nuevo contenido del segundo csv
                    empleados.add(new Employee(id, nombre, apellidos, departamento));
                }
            }

            // Sobreescribimos el archivo original con la lista completa
            if (csvOriginal != null) {
                try (BufferedWriter bw = new BufferedWriter(new FileWriter(csvOriginal))) {
                    for (Employee e : empleados) {
                        bw.write(e.getId() + "," + e.getNombre() + "," + e.getApellido() + "," + e.getDepartamento());
                        bw.newLine();
                    }
                }
            }else{
                return false;
            }

            return true;
        } catch (Exception e) {
            return false;
        }
    }

    public List<Employee> getEmpleados() {
        return empleados;
    }

    public List<Employee> buscarPorId(int id) {
        return empleados.stream().filter(e -> e.getId() == id).collect(Collectors.toList());
    }

    public void ordenarPor(String criterio) {
        if ("ID".equalsIgnoreCase(criterio)) {
            empleados.sort(Comparator.comparingInt(Employee::getId));
        } else if ("Apellido".equalsIgnoreCase(criterio)) {
             empleados.sort(Comparator.comparing(Employee::getApellido));
        } else if ("Departamento".equalsIgnoreCase(criterio)) {
            empleados.sort(Comparator.comparingInt(Employee::getDepartamento));
        }
    }
}

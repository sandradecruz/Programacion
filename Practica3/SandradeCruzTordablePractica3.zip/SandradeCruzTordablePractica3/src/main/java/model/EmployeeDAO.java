/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package model;

import java.io.*;
import java.util.*;
import java.util.stream.Collectors;

/**
 *
 * @author sancru
 */
public class EmployeeDAO {
    private List<Employee> empleados = new ArrayList<>();

    public boolean cargarCSV(String ruta) {
        empleados.clear();
        try (BufferedReader br = new BufferedReader(new FileReader(ruta))) {
            String linea;
            while ((linea = br.readLine()) != null) {
                String[] partes = linea.split(",");
                if (partes.length == 4) {
                    int id = Integer.parseInt(partes[0].trim());
                    String nombre = partes[1].trim();
                    String apellido = partes[2].trim();
                    String depStr = partes[3].trim();
                    int departamento;

                    if (depStr.isEmpty() || depStr.equals("-")) {
                        departamento = -1; //No tiene departamento
                    } else {
                        departamento = Integer.parseInt(depStr);
                    }

                    empleados.add(new Employee(id, nombre, apellido, departamento));
                }
            }
            return true;
        } catch (Exception e) {
            return false; 
        }
    }

    public boolean fusionarCSV(String ruta) {
        try (BufferedReader br = new BufferedReader(new FileReader(ruta))) {
            String linea;
            while ((linea = br.readLine()) != null) {
                String[] partes = linea.split(",");
                if (partes.length >= 4) {
                    int id = Integer.parseInt(partes[0].trim());
                    if (empleados.stream().noneMatch(emp -> emp.getId() == id)) {
                        String depStr = partes[3].trim();
                        int departamento;
                        if (depStr.isEmpty() || depStr.equals("-")) {
                            departamento = -1; //No tiene departamento
                        } else {
                            empleados.add(new Employee(id, partes[1].trim(), partes[2].trim(), Integer.parseInt(partes[3].trim())));  
                        }
                        
                    }
                }
            }
            return true;
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }

    public List<Employee> getEmpleados() {
        return empleados;
    }

    public List<Employee> buscarPorId(int id) {
        return empleados.stream().filter(e -> e.getId() == id).collect(Collectors.toList());
    }

    public void ordenarPor(String criterio) {
        if ("ID".equalsIgnoreCase(criterio)) {
            empleados.sort(Comparator.comparingInt(Employee::getId));
        } else if ("Apellidos".equalsIgnoreCase(criterio)) {
             empleados.sort(Comparator.comparing(e -> e.getApellido()));
        } else if ("Departamento".equalsIgnoreCase(criterio)) {
            empleados.sort(Comparator.comparingInt(Employee::getDepartamento));
        }
    }
}

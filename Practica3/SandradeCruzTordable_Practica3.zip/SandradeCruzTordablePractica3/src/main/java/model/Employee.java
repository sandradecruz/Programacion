/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package model;

/**
 *
 * @author sancru
 */
public class Employee {
    private int id;
    private String nombre;
    private String apellido;
    private int departamento;

    public Employee(int id, String nombre, String apellido, int departamento) {
        this.id = id;
        this.nombre = nombre;
        this.apellido = apellido;
        this.departamento = departamento;
    }

    public int getId() { 
        return id; 
    }
    
    public String getNombre() { 
        return nombre; 
    }
    
    public String getApellido() { 
        return apellido; 
    }
    
    public int getDepartamento() { 
        return departamento; 
    }

    @Override
    public String toString() {
        return id + " - " + nombre + " " + apellido + " (" + departamento + ")";
    }
}

package model;

import java.awt.Color;

public class Simbolo  {    
    private int idSimbolo;
    private String nombre;
    private String caracter;
    private int ascii;
    private int tamanio;
    private Color color;

    public Simbolo() {
    }

    public Simbolo( String nombre, String caracter, int ascii, int tamanio, Color color) {
        this.nombre = nombre;
        this.caracter = caracter;
        this.ascii = ascii;
        this.tamanio = tamanio;
        this.color = color;
    }

      
      
    public int getIdSimbolo() {
        return idSimbolo;
    }

    public void setIdSimbolo(int idSimbolo) {
        this.idSimbolo = idSimbolo;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getCaracter() {
        return caracter;
    }

    public void setCaracter(String caracter) {
        this.caracter = caracter;
    }

    public int getAscii() {
        return ascii;
    }

    public void setAscii(int ascii) {
        this.ascii = ascii;
    }

    public int getTamanio() {
        return tamanio;
    }

    public void setTamanio(int tamanio) {
        this.tamanio = tamanio;
    }

    public Color getColor() {
        return color;
    }

    public void setColor(Color color) {
        this.color = color;
    }

    @Override
    public String toString() {
        return  nombre ;
    }
    
    
      
}

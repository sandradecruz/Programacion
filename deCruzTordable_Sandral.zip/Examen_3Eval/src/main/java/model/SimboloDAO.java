package model;

import java.awt.Color;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class SimboloDAO {
    
    public static DatabaseConnection DBConnection = new DatabaseConnection();
    public static Connection conn;

    public Simbolo getObjetoSimbolo(int idSimbolo) throws SQLException{
        Simbolo simbolo = null;
        //Hacemos la conexion con la base de datos
        conn = DBConnection.getConnection();
        String sql = "select * from simbolo where idSimbolo="+idSimbolo;
        
        PreparedStatement ps = conn.prepareStatement(sql);
        ResultSet rs = ps.executeQuery();
        
        while(rs.next()){
            String nom=rs.getString("nombre");
            String car=rs.getString("caracter");
            int ascii=rs.getInt("ascii");
            int tamanio=rs.getInt("tamanio");
            String colorString = rs.getString("color");
            //Convertimos a color
            Color color = Color.getColor(colorString);
            simbolo = new Simbolo(nom,car,ascii,tamanio,color);
        }
        
        //Devolvemos el simbolor que añadiremos en la lista mas adelante
        return simbolo;
    }
    
    //Metodo para insertar el simbolo que el usuario haya seleccionado
    public boolean insertarSimbolo(String nombre, String caracter, int ascii, int tamanio, String color) throws SQLException{
        conn = DBConnection.getConnection();
        String sql = "insert into simbolo(nombre,caracter,ascii,tamanio,color) values(?,?,?,?,?);";        
        PreparedStatement ps = conn.prepareStatement(sql);
        ps.setString(1, nombre);
        ps.setString(2, caracter);
        ps.setInt(3, ascii);
        ps.setInt(4, tamanio);
        ps.setString(5, color);
        
        boolean resultado = ps.execute();

        return resultado;
    }
    
    public int conteoSimbolos(int ascii) throws SQLException{
        int numSimbolos=0;
        conn = DBConnection.getConnection();
        String sql = "select count(*) from simbolo where ascii="+ascii;
        
        PreparedStatement ps = conn.prepareStatement(sql);
        ResultSet rs = ps.executeQuery();
        
        while(rs.next()){
            numSimbolos= rs.getInt(1);
        }
        
        return numSimbolos;
    }
    
}

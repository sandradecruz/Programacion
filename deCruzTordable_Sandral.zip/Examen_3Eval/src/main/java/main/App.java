package main;

import java.sql.SQLException;
import view.PrincipalView;

public class App {
    
    public static void main(String[] args) throws SQLException {
      PrincipalView view = new PrincipalView();
      
      //Mostramos la ventana al ejercutar el programa
      view.setVisible(true);
        
    }
}

